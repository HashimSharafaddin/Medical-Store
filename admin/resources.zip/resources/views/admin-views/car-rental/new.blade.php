@extends('layouts.admin.app')

@section('title',translate('messages.car'))

@push('css_or_js')

@endpush

@section('content')

@endsection

@push('script_2')

@endpush
